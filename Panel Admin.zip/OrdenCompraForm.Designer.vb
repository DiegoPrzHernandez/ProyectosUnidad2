﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OrdenCompraForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        txtCantidad = New TextBox()
        btnEnviar = New Button()
        btnVolver = New Button()
        cmbCodigo = New ComboBox()
        cmbProducto = New ComboBox()
        cmbProveedor = New ComboBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Thistle
        Label1.Font = New Font("Palatino Linotype", 16.2F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(68, 59)
        Label1.Name = "Label1"
        Label1.Size = New Size(241, 37)
        Label1.TabIndex = 0
        Label1.Text = "Código del producto"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Thistle
        Label2.Font = New Font("Palatino Linotype", 16.2F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(57, 109)
        Label2.Name = "Label2"
        Label2.Size = New Size(252, 37)
        Label2.TabIndex = 1
        Label2.Text = "Nombre del producto"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Thistle
        Label3.Font = New Font("Palatino Linotype", 16.2F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(72, 167)
        Label3.Name = "Label3"
        Label3.Size = New Size(237, 37)
        Label3.TabIndex = 2
        Label3.Text = "Cantidad solicitada"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Thistle
        Label4.Font = New Font("Palatino Linotype", 16.2F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(181, 226)
        Label4.Name = "Label4"
        Label4.Size = New Size(128, 37)
        Label4.TabIndex = 3
        Label4.Text = "Proveedor"
        ' 
        ' txtCantidad
        ' 
        txtCantidad.Font = New Font("Palatino Linotype", 13.8F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        txtCantidad.ForeColor = Color.Red
        txtCantidad.Location = New Point(329, 167)
        txtCantidad.Name = "txtCantidad"
        txtCantidad.Size = New Size(165, 39)
        txtCantidad.TabIndex = 6
        ' 
        ' btnEnviar
        ' 
        btnEnviar.BackColor = SystemColors.ActiveCaption
        btnEnviar.Font = New Font("Palatino Linotype", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnEnviar.Location = New Point(489, 397)
        btnEnviar.Name = "btnEnviar"
        btnEnviar.Size = New Size(147, 39)
        btnEnviar.TabIndex = 8
        btnEnviar.Text = "Enviar Orden"
        btnEnviar.UseVisualStyleBackColor = False
        ' 
        ' btnVolver
        ' 
        btnVolver.BackColor = SystemColors.ActiveCaption
        btnVolver.Font = New Font("Palatino Linotype", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnVolver.Location = New Point(655, 398)
        btnVolver.Name = "btnVolver"
        btnVolver.Size = New Size(108, 40)
        btnVolver.TabIndex = 9
        btnVolver.Text = "Volver"
        btnVolver.UseVisualStyleBackColor = False
        ' 
        ' cmbCodigo
        ' 
        cmbCodigo.Font = New Font("Palatino Linotype", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cmbCodigo.ForeColor = Color.Red
        cmbCodigo.FormattingEnabled = True
        cmbCodigo.Location = New Point(329, 59)
        cmbCodigo.Name = "cmbCodigo"
        cmbCodigo.Size = New Size(165, 39)
        cmbCodigo.TabIndex = 10
        ' 
        ' cmbProducto
        ' 
        cmbProducto.Font = New Font("Palatino Linotype", 13.8F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        cmbProducto.ForeColor = Color.Red
        cmbProducto.FormattingEnabled = True
        cmbProducto.Location = New Point(329, 111)
        cmbProducto.Name = "cmbProducto"
        cmbProducto.Size = New Size(202, 39)
        cmbProducto.TabIndex = 11
        ' 
        ' cmbProveedor
        ' 
        cmbProveedor.Font = New Font("Palatino Linotype", 13.8F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        cmbProveedor.ForeColor = Color.Red
        cmbProveedor.FormattingEnabled = True
        cmbProveedor.Location = New Point(329, 226)
        cmbProveedor.Name = "cmbProveedor"
        cmbProveedor.Size = New Size(165, 39)
        cmbProveedor.TabIndex = 12
        ' 
        ' OrdenCompraForm
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.tires_road_1265x633_862x431
        ClientSize = New Size(800, 450)
        Controls.Add(cmbProveedor)
        Controls.Add(cmbProducto)
        Controls.Add(cmbCodigo)
        Controls.Add(btnVolver)
        Controls.Add(btnEnviar)
        Controls.Add(txtCantidad)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "OrdenCompraForm"
        Text = "OrdenCompraForm"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtCantidad As TextBox
    Friend WithEvents btnEnviar As Button
    Friend WithEvents btnVolver As Button
    Friend WithEvents cmbCodigo As ComboBox
    Friend WithEvents cmbProducto As ComboBox
    Friend WithEvents cmbProveedor As ComboBox
End Class
