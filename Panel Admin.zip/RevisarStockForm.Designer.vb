﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RevisarStockForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblTitulo = New Label()
        dgvStock = New DataGridView()
        btnVolver = New Button()
        CType(dgvStock, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("Showcard Gothic", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblTitulo.Location = New Point(27, 9)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(339, 43)
        lblTitulo.TabIndex = 0
        lblTitulo.Text = "Revisión de Stock"
        lblTitulo.TextAlign = ContentAlignment.TopCenter
        ' 
        ' dgvStock
        ' 
        dgvStock.AllowUserToAddRows = False
        dgvStock.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvStock.Location = New Point(27, 71)
        dgvStock.Name = "dgvStock"
        dgvStock.ReadOnly = True
        dgvStock.RowHeadersWidth = 51
        dgvStock.Size = New Size(857, 423)
        dgvStock.TabIndex = 1
        ' 
        ' btnVolver
        ' 
        btnVolver.BackColor = Color.IndianRed
        btnVolver.Font = New Font("Palatino Linotype", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnVolver.ForeColor = Color.Black
        btnVolver.Location = New Point(657, 9)
        btnVolver.Name = "btnVolver"
        btnVolver.Size = New Size(227, 56)
        btnVolver.TabIndex = 2
        btnVolver.Text = "Volver al Menú"
        btnVolver.UseVisualStyleBackColor = False
        ' 
        ' RevisarStockForm
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.mechanic_service_is_changing_new_tires_and_wheels_on_the_garage_background_photo
        ClientSize = New Size(1046, 506)
        Controls.Add(btnVolver)
        Controls.Add(dgvStock)
        Controls.Add(lblTitulo)
        Name = "RevisarStockForm"
        Text = "RevisarStockForm"
        CType(dgvStock, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitulo As Label
    Friend WithEvents dgvStock As DataGridView
    Friend WithEvents btnVolver As Button
End Class
