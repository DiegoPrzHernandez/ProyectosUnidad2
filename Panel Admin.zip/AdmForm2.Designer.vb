﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdmForm2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblTitulo = New Label()
        btnRevisarStock = New Button()
        btnAbastecer = New Button()
        btnBajaRotacion = New Button()
        btnOrdenCompra = New Button()
        SuspendLayout()
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.BackColor = SystemColors.ActiveCaption
        lblTitulo.Font = New Font("Segoe Print", 24F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitulo.Location = New Point(247, 34)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(331, 71)
        lblTitulo.TabIndex = 0
        lblTitulo.Text = "Menú Principal"
        ' 
        ' btnRevisarStock
        ' 
        btnRevisarStock.BackColor = SystemColors.InactiveCaption
        btnRevisarStock.Font = New Font("Segoe Print", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnRevisarStock.Location = New Point(215, 157)
        btnRevisarStock.Name = "btnRevisarStock"
        btnRevisarStock.Size = New Size(172, 40)
        btnRevisarStock.TabIndex = 1
        btnRevisarStock.Text = "Revisar Stock"
        btnRevisarStock.UseVisualStyleBackColor = False
        ' 
        ' btnAbastecer
        ' 
        btnAbastecer.BackColor = SystemColors.InactiveCaption
        btnAbastecer.Font = New Font("Segoe Print", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAbastecer.Location = New Point(215, 248)
        btnAbastecer.Name = "btnAbastecer"
        btnAbastecer.Size = New Size(172, 40)
        btnAbastecer.TabIndex = 2
        btnAbastecer.Text = "Abastecer"
        btnAbastecer.UseVisualStyleBackColor = False
        ' 
        ' btnBajaRotacion
        ' 
        btnBajaRotacion.BackColor = SystemColors.InactiveCaption
        btnBajaRotacion.Font = New Font("Segoe Print", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBajaRotacion.Location = New Point(448, 157)
        btnBajaRotacion.Name = "btnBajaRotacion"
        btnBajaRotacion.Size = New Size(172, 40)
        btnBajaRotacion.TabIndex = 3
        btnBajaRotacion.Text = "Baja Rotación"
        btnBajaRotacion.UseVisualStyleBackColor = False
        ' 
        ' btnOrdenCompra
        ' 
        btnOrdenCompra.BackColor = SystemColors.InactiveCaption
        btnOrdenCompra.Font = New Font("Segoe Print", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnOrdenCompra.Location = New Point(448, 248)
        btnOrdenCompra.Name = "btnOrdenCompra"
        btnOrdenCompra.Size = New Size(172, 38)
        btnOrdenCompra.TabIndex = 4
        btnOrdenCompra.Text = "Orden de Compra"
        btnOrdenCompra.UseVisualStyleBackColor = False
        ' 
        ' AdmForm2
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.istockphoto_1148964597_612x612
        ClientSize = New Size(800, 450)
        Controls.Add(btnOrdenCompra)
        Controls.Add(btnBajaRotacion)
        Controls.Add(btnAbastecer)
        Controls.Add(btnRevisarStock)
        Controls.Add(lblTitulo)
        Name = "AdmForm2"
        Text = "AdmForm2"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitulo As Label
    Friend WithEvents btnRevisarStock As Button
    Friend WithEvents btnAbastecer As Button
    Friend WithEvents btnBajaRotacion As Button
    Friend WithEvents btnOrdenCompra As Button
End Class
