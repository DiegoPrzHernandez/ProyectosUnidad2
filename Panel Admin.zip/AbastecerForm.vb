﻿Public Class AbastecerForm
    Inherits Form
    Private Sub AbastecerForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Llenar ComboBox de Códigos
        cmbCodigo.Items.Add("LL001")
        cmbCodigo.Items.Add("LL002")
        cmbCodigo.Items.Add("LL003")
        cmbCodigo.Items.Add("LL004")
        cmbCodigo.Items.Add("LL005")
        cmbCodigo.Items.Add("LL006")
        cmbCodigo.Items.Add("LL007")
        cmbCodigo.Items.Add("LL008")
        cmbCodigo.Items.Add("LL009")
        cmbCodigo.Items.Add("LL010")
        cmbCodigo.Items.Add("LL011")
        cmbCodigo.Items.Add("LL012")
        cmbCodigo.Items.Add("LL013")
        cmbCodigo.Items.Add("LL014")
        cmbCodigo.Items.Add("LL015")
        cmbCodigo.Items.Add("LL016")

        ' Llenar ComboBox de Productos
        cmbProducto.Items.Add("Llantas 14'' Michelin")
        cmbProducto.Items.Add("Llantas 15'' Pirelli")
        cmbProducto.Items.Add("Llantas 16'' Bridgestone")
        cmbProducto.Items.Add("Llantas 17'' Firestone")
        cmbProducto.Items.Add("Llantas 13'' Hankook")
        cmbProducto.Items.Add("Llantas 18'' Goodyear")
        cmbProducto.Items.Add("Llantas 12'' Toyo")
        cmbProducto.Items.Add("Llantas 20'' Continental")
        cmbProducto.Items.Add("Llantas 19'' Dunlop")
        cmbProducto.Items.Add("Llantas 15'' General Tire")
        cmbProducto.Items.Add("Llantas 19'' WestLake")
        cmbProducto.Items.Add("Llantas 16'' Nexen")
        cmbProducto.Items.Add("Llantas 17'' Kumho")
        cmbProducto.Items.Add("Llantas 20'' LingLong")
        cmbProducto.Items.Add("Llantas 14'' Giti")
        cmbProducto.Items.Add("Llantas 12'' Maxxis")

        ' Llenar ComboBox de Ubicaciones
        cmbUbicacion.Items.Add("Estante A1")
        cmbUbicacion.Items.Add("Estante A2")
        cmbUbicacion.Items.Add("Estante A3")
        cmbUbicacion.Items.Add("Estante A4")
        cmbUbicacion.Items.Add("Estante B1")
        cmbUbicacion.Items.Add("Estante B2")
        cmbUbicacion.Items.Add("Estante B3")
        cmbUbicacion.Items.Add("Estante C1")
        cmbUbicacion.Items.Add("Estante C2")
        cmbUbicacion.Items.Add("Estante D1")
        cmbUbicacion.Items.Add("Estante D2")
        cmbUbicacion.Items.Add("Estante D3")
        cmbUbicacion.Items.Add("Estante E1")
        cmbUbicacion.Items.Add("Estante E2")
        cmbUbicacion.Items.Add("Estante E3")
        cmbUbicacion.Items.Add("Estante F1")

        ' Opcional: Seleccionar primero vacío
        cmbCodigo.SelectedIndex = -1
        cmbProducto.SelectedIndex = -1
        cmbUbicacion.SelectedIndex = -1
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub txtCantidad_TextChanged(sender As Object, e As EventArgs) Handles txtCantidad.TextChanged

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click
        Dim codigo As String = cmbCodigo.Text
        Dim producto As String = cmbProducto.Text
        Dim cantidad As String = txtCantidad.Text
        Dim ubicacion As String = cmbUbicacion.Text

        ' Validación de campos vacíos
        If codigo = "" Or producto = "" Or cantidad = "" Or ubicacion = "" Then
            MessageBox.Show("Por favor completa todos los campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Validación: cantidad debe ser un número positivo
        If Not IsNumeric(cantidad) Or Val(cantidad) <= 0 Then
            MessageBox.Show("La cantidad debe ser un número válido mayor que cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' Mensaje de confirmación
        MessageBox.Show("Producto abastecido correctamente." & vbCrLf &
                        "Código: " & codigo & vbCrLf &
                        "Producto: " & producto & vbCrLf &
                        "Cantidad: " & cantidad & vbCrLf &
                        "Ubicación: " & ubicacion, "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)

        ' Limpiar campos
        cmbCodigo.SelectedIndex = -1
        cmbProducto.SelectedIndex = -1
        txtCantidad.Clear()
        cmbUbicacion.SelectedIndex = -1
    End Sub

    Private Sub btnVolver_Click(sender As Object, e As EventArgs) Handles btnVolver.Click
        Me.Close()
    End Sub

    Private Sub cmbCodigo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbCodigo.SelectedIndexChanged

    End Sub

    Private Sub cmbProducto_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbProducto.SelectedIndexChanged

    End Sub

    Private Sub cmbUbicacion_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbUbicacion.SelectedIndexChanged

    End Sub
End Class