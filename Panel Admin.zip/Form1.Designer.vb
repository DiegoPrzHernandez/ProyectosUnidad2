﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblUsuario = New Label()
        txtUsuario = New TextBox()
        Label1 = New Label()
        txtContrasena = New TextBox()
        btnIniciarSesion = New Button()
        lblError = New Label()
        SuspendLayout()
        ' 
        ' lblUsuario
        ' 
        lblUsuario.AutoSize = True
        lblUsuario.BackColor = Color.Beige
        lblUsuario.Font = New Font("Times New Roman", 18F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        lblUsuario.Location = New Point(356, 59)
        lblUsuario.Name = "lblUsuario"
        lblUsuario.Size = New Size(124, 35)
        lblUsuario.TabIndex = 0
        lblUsuario.Text = "Usuario:"
        ' 
        ' txtUsuario
        ' 
        txtUsuario.Font = New Font("Times New Roman", 13.8F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        txtUsuario.Location = New Point(328, 97)
        txtUsuario.Name = "txtUsuario"
        txtUsuario.Size = New Size(173, 34)
        txtUsuario.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Beige
        Label1.Font = New Font("Times New Roman", 18.0F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(328, 163)
        Label1.Name = "Label1"
        Label1.Size = New Size(173, 35)
        Label1.TabIndex = 2
        Label1.Text = " Contraseña:"
        ' 
        ' txtContrasena
        ' 
        txtContrasena.Font = New Font("Times New Roman", 13.8F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        txtContrasena.Location = New Point(328, 201)
        txtContrasena.Name = "txtContrasena"
        txtContrasena.Size = New Size(173, 34)
        txtContrasena.TabIndex = 3
        txtContrasena.UseSystemPasswordChar = True
        ' 
        ' btnIniciarSesion
        ' 
        btnIniciarSesion.BackColor = Color.Beige
        btnIniciarSesion.Font = New Font("Times New Roman", 16.2F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        btnIniciarSesion.ForeColor = SystemColors.ActiveCaptionText
        btnIniciarSesion.Location = New Point(301, 273)
        btnIniciarSesion.Name = "btnIniciarSesion"
        btnIniciarSesion.Size = New Size(224, 68)
        btnIniciarSesion.TabIndex = 4
        btnIniciarSesion.Text = "Iniciar Sesión"
        btnIniciarSesion.UseVisualStyleBackColor = False
        ' 
        ' lblError
        ' 
        lblError.AutoSize = True
        lblError.ForeColor = Color.Red
        lblError.Location = New Point(319, 321)
        lblError.Name = "lblError"
        lblError.Size = New Size(0, 20)
        lblError.TabIndex = 5
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.pngtree_3drendering_of_tyres_on_the_sidewalk_picture_image_2689682
        ClientSize = New Size(838, 495)
        Controls.Add(lblError)
        Controls.Add(btnIniciarSesion)
        Controls.Add(txtContrasena)
        Controls.Add(Label1)
        Controls.Add(txtUsuario)
        Controls.Add(lblUsuario)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblUsuario As Label
    Friend WithEvents txtUsuario As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtContrasena As TextBox
    Friend WithEvents btnIniciarSesion As Button
    Friend WithEvents lblError As Label

End Class
